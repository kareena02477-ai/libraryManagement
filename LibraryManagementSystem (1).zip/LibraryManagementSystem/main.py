import sqlite3
from datetime import date

DB_NAME = "library.db"


def connect_db():
    """Connect to SQLite and create tables if they do not exist."""
    conn = sqlite3.connect(DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            quantity INTEGER NOT NULL CHECK (quantity >= 0)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS issued_books (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            student_name TEXT NOT NULL,
            issue_date TEXT NOT NULL,
            return_date TEXT,
            FOREIGN KEY (book_id) REFERENCES books(id)
        )
    """)
    conn.commit()
    return conn


def add_book():
    title = input("Book title: ").strip()
    author = input("Author name: ").strip()

    if not title or not author:
        print("Title aur author khali nahi ho sakte.")
        return

    try:
        quantity = int(input("Quantity: "))
        if quantity < 0:
            print("Quantity 0 ya usse zyada honi chahiye.")
            return
    except ValueError:
        print("Quantity ke liye number enter karein.")
        return

    with connect_db() as conn:
        conn.execute(
            "INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)",
            (title, author, quantity)
        )
    print("Book successfully add ho gayi.")


def view_books():
    with connect_db() as conn:
        books = conn.execute(
            "SELECT id, title, author, quantity FROM books ORDER BY id"
        ).fetchall()

    if not books:
        print("Abhi koi book saved nahi hai.")
        return

    print("\n--- BOOK LIST ---")
    print(f"{'ID':<5}{'Title':<30}{'Author':<25}{'Available':<10}")
    print("-" * 70)
    for book_id, title, author, quantity in books:
        print(f"{book_id:<5}{title[:28]:<30}{author[:23]:<25}{quantity:<10}")


def search_book():
    keyword = input("Book title ya author ka naam: ").strip()
    with connect_db() as conn:
        books = conn.execute(
            """SELECT id, title, author, quantity
               FROM books
               WHERE title LIKE ? OR author LIKE ?
               ORDER BY title""",
            (f"%{keyword}%", f"%{keyword}%")
        ).fetchall()

    if not books:
        print("Koi matching book nahi mili.")
        return

    print("\n--- SEARCH RESULTS ---")
    for book_id, title, author, quantity in books:
        print(f"ID: {book_id} | Title: {title} | Author: {author} | Available: {quantity}")


def issue_book():
    view_books()
    try:
        book_id = int(input("\nIssue karne ke liye Book ID: "))
    except ValueError:
        print("Book ID number mein enter karein.")
        return

    student_name = input("Student ka naam: ").strip()
    if not student_name:
        print("Student ka naam zaroori hai.")
        return

    with connect_db() as conn:
        book = conn.execute(
            "SELECT title, quantity FROM books WHERE id = ?", (book_id,)
        ).fetchone()

        if book is None:
            print("Invalid Book ID.")
            return
        if book[1] <= 0:
            print("Ye book abhi available nahi hai.")
            return

        conn.execute(
            "UPDATE books SET quantity = quantity - 1 WHERE id = ?", (book_id,)
        )
        conn.execute(
            """INSERT INTO issued_books (book_id, student_name, issue_date)
               VALUES (?, ?, ?)""",
            (book_id, student_name, date.today().isoformat())
        )

    print(f"'{book[0]}' {student_name} ko issue ho gayi.")


def view_issued_books():
    with connect_db() as conn:
        rows = conn.execute("""
            SELECT i.id, b.title, i.student_name, i.issue_date
            FROM issued_books AS i
            JOIN books AS b ON b.id = i.book_id
            WHERE i.return_date IS NULL
            ORDER BY i.id
        """).fetchall()

    if not rows:
        print("Abhi koi book issue par nahi hai.")
        return

    print("\n--- CURRENTLY ISSUED BOOKS ---")
    for issue_id, title, student, issue_date in rows:
        print(
            f"Issue ID: {issue_id} | Book: {title} | "
            f"Student: {student} | Issue date: {issue_date}"
        )


def return_book():
    view_issued_books()
    try:
        issue_id = int(input("\nReturn karne ke liye Issue ID: "))
    except ValueError:
        print("Issue ID number mein enter karein.")
        return

    with connect_db() as conn:
        row = conn.execute(
            """SELECT book_id, student_name FROM issued_books
               WHERE id = ? AND return_date IS NULL""",
            (issue_id,)
        ).fetchone()

        if row is None:
            print("Active Issue ID nahi mili. ID check karein.")
            return

        book_id, student_name = row
        conn.execute(
            "UPDATE issued_books SET return_date = ? WHERE id = ?",
            (date.today().isoformat(), issue_id)
        )
        conn.execute(
            "UPDATE books SET quantity = quantity + 1 WHERE id = ?", (book_id,)
        )

    print(f"{student_name} ki book successfully return ho gayi.")


def main():
    # Create the database and tables before showing the menu.
    connect_db().close()

    while True:
        print("\n========== LIBRARY MANAGEMENT SYSTEM ==========")
        print("1. Add Book")
        print("2. View All Books")
        print("3. Search Book")
        print("4. Issue Book")
        print("5. Return Book")
        print("6. View Issued Books")
        print("7. Exit")

        choice = input("Apna option choose karein (1-7): ").strip()

        if choice == "1":
            add_book()
        elif choice == "2":
            view_books()
        elif choice == "3":
            search_book()
        elif choice == "4":
            issue_book()
        elif choice == "5":
            return_book()
        elif choice == "6":
            view_issued_books()
        elif choice == "7":
            print("Library Management System use karne ke liye thanks!")
            break
        else:
            print("Invalid option. 1 se 7 ke beech choose karein.")


if __name__ == "__main__":
    main()
